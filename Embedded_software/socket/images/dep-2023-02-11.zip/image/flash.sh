#/usr/bin/env bash

echo "=================================="
echo " Will flash the Image load..."
echo "=================================="

sleep 2

uuu -b emmc_all boot mono-system.img